/**
 * CWIPServiceService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.travelsky.et.web.cwip;

public interface CWIPServiceService extends javax.xml.rpc.Service {
    public java.lang.String getCWIPServiceAddress();

    public com.travelsky.et.web.cwip.CWIPService getCWIPService() throws javax.xml.rpc.ServiceException;

    public com.travelsky.et.web.cwip.CWIPService getCWIPService(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
